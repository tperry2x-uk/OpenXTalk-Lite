{
	"name": "org.openxtalk.library.libsvgicons",
	"display name": "OpenXTalk libSVGIcons",
	"group": "Extensions",
	"location": "/Applications/OpenXTalk 1.963.1rc4.app/Contents/Tools/Extensions/org.openxtalk.library.libsvgicons/docs/guide",
"data":"# libSVGicons\nThis is a library meant to compliment the IconSVG library in the IDE.\n\nA main feature is support for loading DVG Icon sets stored in a simple\ntab-seperated-values (TSV) list. These TSV Icon lists can be created from\n\"-webfont.svg\" formated font commonly found on the internet and supported by\ntools such as the cross-platform, open-source fontForge application.\n\nIncluded with the library are several liberally licensed Icon sets, the biggest    \nof these sets being Google's Material Icon project (v.4.0 currently).\nMaterial Icons set contains 6,063 glyphs so there may be a slight delay\n(0.5 second or so) when initially loading that set.\n \n\n![Icon picker](images/icon-picker.png)\n"
}