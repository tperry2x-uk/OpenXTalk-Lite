{
			"id":"com.livecode.widget.native.mac.textfield-1",
			"name":"com.livecode.widget.native.mac.textfield",
			"display name":"Mac Native Single-line Field",
			"library":"com.livecode.widget.native.mac.textfield",
			"type":"widget",
			"display syntax":[
				"Mac Native Single-line Field"
			],
			"associations":["com.livecode.widget.native.mac.textfield"],
			"summary":"This widget wraps the native NSTextField on Mac. Since this is\na single-line field, the return key does not enter a new line,\ninstead it triggers the returnKey action and the contents of\nthe field is selected.",
			"OS":["mac"],
			"description":"This widget wraps the native NSTextField on Mac. Since this is\na single-line field, the return key does not enter a new line,\ninstead it triggers the returnKey action and the contents of\nthe field is selected."
		},{
			"id":"com.livecode.widget.native.mac.textfield-2",
			"name":"enabled",
			"display name":"enabled",
			"library":"com.livecode.widget.native.mac.textfield",
			"type":"property",
			"syntax":[
				"set the enabled of <widget> to {true | false}\nget the enabled of <widget>"
			],
			"display syntax":[
				"set the enabled of <i>widget</i> to {true | false}"
			],
			"associations":["com.livecode.widget.native.mac.textfield"],
			"summary":"The enabled state of the text field",
			"OS":["mac"],
			"description":"Use the <enabled> property to enable or disable the native field. When\ndisabled, the text has a greyed out appearance and the field contents\ncannot be edited."
		},{
			"id":"com.livecode.widget.native.mac.textfield-3",
			"name":"returnkey",
			"display name":"returnKey",
			"library":"com.livecode.widget.native.mac.textfield",
			"type":"message",
			"syntax":[
				"on returnKey"
			],
			"display syntax":[
				"on returnKey"
			],
			"associations":["com.livecode.widget.native.mac.textfield"],
			"summary":"Sent when the user presses the return key",
			"OS":["mac"],
			"examples":[{
				"script":"on returnKey\n    -- ensure the user has entered a number\n    if the text of the target is not a number then\n      beep\n      answer \"Invalid number entered!\"\n    end if\nend returnKey"
			}],
			"description":"Use the <returnKey> message to respond to the user pressing the return\nkey whilst the field is focused."
		},{
			"id":"com.livecode.widget.native.mac.textfield-4",
			"name":"showfocusborder",
			"display name":"showFocusBorder",
			"library":"com.livecode.widget.native.mac.textfield",
			"type":"property",
			"syntax":[
				"set the showFocusBorder of <widget> to { true | false }\nget the showFocusBorder of <widget>"
			],
			"display syntax":[
				"set the showFocusBorder of <i>widget</i> to { true | false }"
			],
			"associations":["com.livecode.widget.native.mac.textfield"],
			"summary":"Whether the text field has a focus border or not",
			"OS":["mac"],
			"description":"Use the <showFocusBorder> property to control whether the field\nwidget displays a blue border when focused or not."
		},{
			"id":"com.livecode.widget.native.mac.textfield-5",
			"name":"showborder",
			"display name":"showBorder",
			"library":"com.livecode.widget.native.mac.textfield",
			"type":"property",
			"syntax":[
				"set the showBorder of <widget> to { true | false }\nget the showBorder of <widget>"
			],
			"display syntax":[
				"set the showBorder of <i>widget</i> to { true | false }"
			],
			"associations":["com.livecode.widget.native.mac.textfield"],
			"summary":"Whether the text field has a border or not",
			"OS":["mac"],
			"description":"Use the <showBorder> property to control whether the field\nwidget has a border or not."
		},{
			"id":"com.livecode.widget.native.mac.textfield-6",
			"name":"text",
			"display name":"text",
			"library":"com.livecode.widget.native.mac.textfield",
			"type":"property",
			"syntax":[
				"set the text of <widget> to <pText>\nget the text of <widget>"
			],
			"display syntax":[
				"set the text of <i>widget</i> to <i>pText</i>"
			],
			"associations":["com.livecode.widget.native.mac.textfield"],
			"summary":"The text displayed by the widget",
			"OS":["mac"],
			"examples":[{
				"script":"local sEntered\non returnKey\n    -- store the entered text and clear the field\n    put the text of the target into sEntered\n    set the text of the target to empty\nend returnKey"
			}],
			"value":[{
				"name":"value",
				"type":"",
				"description":"The text of the widget"
			}],
			"description":"Use the <text> property to get or set the text displayed\nby the field widget.\n"
		}